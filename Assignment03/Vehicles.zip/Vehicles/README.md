# Vehicles

## Usage

To run the Vehicle program, navigate to the `src` directory and run `javac App.java` to compile. Then run `java App` to run the application. The application will instantiate a number of different Vehicle objects and run through a number of methods included each class and print the results of those methods. Finally, the program will make comparisons between each vehicle and print the results.